#ifndef SERVEIMAGE_H
#define SERVEIMAGE_H

#include<QString>
#include<QFileDialog>
#include<QDebug>
#include<QQuickImageProvider>
#include<QBuffer>
#include<QDataStream>
#include<QSharedMemory>
class ServeImage : public QDialog, public QQuickImageProvider
{
    QSharedMemory sharedqt;
    Q_OBJECT

public:
    ServeImage();

    QPixmap requestPixmap(const QString &id, QSize *size, const QSize &requestedSize) override;

    void mperror(char* msg);
};

#endif // SERVEIMAGE_H
