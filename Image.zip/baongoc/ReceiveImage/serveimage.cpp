#include "serveimage.h"
#include<iostream>

ServeImage::ServeImage() : QQuickImageProvider(QQuickImageProvider::Pixmap), sharedqt("sharedimage")
{
}

QPixmap ServeImage::requestPixmap(const QString &id, QSize *size, const QSize &requestedSize){
    qDebug() <<"inside serve image";
    if(!sharedqt.attach()){
        qDebug() <<"fail attach";
    }
    else{
        if(sharedqt.isAttached()){
            qDebug() <<"da duoc gan vao process thu 2";
        }
        else{
            qDebug() <<"k gan duoc la sao";
        }
    }

    QPixmap pixmap;
    QBuffer buffer;
    QDataStream in(&buffer);
    qDebug() <<"Chuan bi khoa";
    sharedqt.lock();
    buffer.setData((char*)sharedqt.constData(), sharedqt.size());
    buffer.open(QBuffer::ReadWrite);
    in >> pixmap;
    sharedqt.unlock();
    qDebug() <<"Da mo khoa";

    if(sharedqt.isAttached()){
        qDebug() <<"nen detach nos di";
        sharedqt.detach();
    }
    return pixmap;
}

void ServeImage::mperror(char *msg){
    perror(msg);
    exit(1);
}
