#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include<QQmlContext>
#include<QApplication>
#include"clientimage.h"
#include <QQuickWindow>
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    ClientImage cli_image;
    QQmlApplicationEngine engine;
    QQmlContext *context = engine.rootContext();
    context->setContextProperty("m_cli_image", &cli_image);

    engine.addImageProvider(QLatin1String("my_image_provider"), new ClientImage);
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));


    return app.exec();
}
