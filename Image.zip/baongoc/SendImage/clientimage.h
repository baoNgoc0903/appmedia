#ifndef CLIENTIMAGE_H
#define CLIENTIMAGE_H

#include<QString>
#include<QFileDialog>
#include<QDebug>
#include<QQuickImageProvider>
#include<QPixmap>
#include<QBuffer>
#include<QSharedMemory>
class ClientImage : public QDialog, public QQuickImageProvider
{
    QSharedMemory sharedqt;
//    bool check;
//    key_t key_size,key_path,key_buffer;
//    int shm_size, shm_path, shm_buffer;
//    int *shared_mem_sizebuffer;
//    char *shared_mem_path;
//    char *shared_mem_buffer;

    Q_OBJECT // k có thằng này thì Q_INVOKABLE vẫn is not a function ở chỗ property from C++ to qml
    QString m_filename;
    Q_PROPERTY(QString m_path READ getPath WRITE setPath NOTIFY pathChanged)

signals:
    void pathChanged();
public:
    ClientImage();
    Q_INVOKABLE QString getIdProvider();
    QPixmap requestPixmap(const QString &id, QSize *size, const QSize &requestedSize) override;

    Q_INVOKABLE QString openImage();
    QString getPath();
    void setPath(QString filename);
    void mperror(char* msg);
};

#endif // CLIENTIMAGE_H
