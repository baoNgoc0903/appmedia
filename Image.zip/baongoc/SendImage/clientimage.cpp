#include "clientimage.h"
#include<QByteArray>
#include<string.h>
#include<QSharedMemory>
ClientImage::ClientImage() :sharedqt("sharedimage"),
    m_filename(""), QQuickImageProvider(QQuickImageProvider::Pixmap)
{
}

QString ClientImage::getIdProvider(){
    QString rm = m_filename;
    return rm. remove(0, 7);
}

QPixmap ClientImage::requestPixmap(const QString &id, QSize *size, const QSize &requestedSize){
    if(sharedqt.isAttached()){
        qInfo() <<"cbi bi tach ra khoi segment";
        if(!sharedqt.detach()){
            qDebug() <<"detach fail";
        }
    }

    QPixmap pixmap;
    if(pixmap.load(id)){
        int x = rand() % pixmap.width() +1;
        int y = rand() % pixmap.height() +1;
        pixmap = pixmap.copy(x,y,x,y); // crop random

        QBuffer buffer;
        buffer.open(QBuffer::ReadWrite);
        QDataStream out(&buffer);
        out << pixmap;
        int size = buffer.size();

        if(!sharedqt.create(size)){
            qDebug() << "create segment fail";
        }
        else{
            if(sharedqt.isAttached()){
                qDebug() <<"vua tao xong la no gan vao pross nay lien";
            }
        }
        qDebug() << "Chuan bi khoa";
        sharedqt.lock();
        char *to = (char*)sharedqt.data();
        const char *from = buffer.data().data();
        memcpy(to, from, qMin(sharedqt.size(), size));
        sharedqt.unlock();
        qDebug() <<"da mo khoa";
        return pixmap;
    }
    else{
        qDebug() << "pixmap load image fail";
        exit(1);
    }
}

QString ClientImage::openImage(){
    QString filename;
    filename = QFileDialog::getOpenFileName(0, "*_*Open Image*_*", "/home/kame/LearnQML/Image","Image file(*.png *.xpm *.jpg)");
//    QByteArray qarr = filename.toLatin1();
//    char *shared_copy;
//    shared_copy = qarr.data();
//    strcpy(shared_mem_path, shared_copy);
    return filename;
}

QString ClientImage::getPath()
{
    return m_filename;
}

void ClientImage::setPath(QString filename)
{
    if(filename!=m_filename){
        m_filename = filename;
        emit pathChanged();
    }
}

void ClientImage::mperror(char *msg){
    perror(msg);
    exit(1);
}
